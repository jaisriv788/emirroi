function Footer() {
  return (
    <div className="bg-gray-400 w-full self-end text-center py-1 text-sm font-semibold">
      Copyright © 2025, All right reserved
    </div>
  );
}

export default Footer;
